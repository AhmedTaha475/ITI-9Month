# doublezoom
A JQuery plugin to zoom and compare different parts of an image


# instructions
1) Move the lens
2) First mouse click freezes the zoomed detail #1
3) Second mouse click freezes the zoomed detail #2
4) Third click restart the procedure

[Demo](http://www.oldauntie.org/doublezoom)
